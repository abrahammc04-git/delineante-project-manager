<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Http;
use App\Models\Proyecto;

class ChatbotController extends Controller
{
    /**
     * Recibe el mensaje del usuario, lo envía a la API de Claude,
     * y devuelve la respuesta en JSON.
     */
    public function consulta(Request $request): JsonResponse
    {
        // Solo admin puede usar el chatbot
        if (auth()->user()->rol !== 'admin') {
            return response()->json(['respuesta' => 'No tienes permisos para usar el asistente.'], 403);
        }

        $mensaje = $request->validate([
            'mensaje' => 'required|string|max:500',
        ])['mensaje'];

        // ── Obtener datos actuales de proyectos para dar contexto a la IA ──
        $proyectos = Proyecto::with('usuario')->get()->map(function ($p) {
            return [
                'id'                  => $p->id_proyecto,
                'nombre'              => $p->nombre_proyecto,
                'cliente'             => $p->usuario ? $p->usuario->nombre . ' ' . $p->usuario->apellidos : 'Sin cliente',
                'estado'              => $p->estado,
                'tipo'                => $p->tipo_proyecto,
                'fecha_inicio'        => $p->fecha_inicio?->format('d/m/Y'),
                'fecha_fin_prevista'  => $p->fecha_fin_prevista?->format('d/m/Y'),
                'fecha_fin_real'      => $p->fecha_fin_real?->format('d/m/Y'),
                'localizacion'        => $p->localizacion,
                'fase_actual'         => $p->fase_actual,
            ];
        })->toArray();

        $contexto = json_encode($proyectos, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

        // ── Llamar a la API de Anthropic (Claude) ──
        $apiKey = config('services.anthropic.key'); // Se configura en .env

        $respuesta = Http::withHeaders([
            'x-api-key'      => $apiKey,
            'anthropic-version' => '2023-06-01',
            'content-type'   => 'application/json',
        ])->post('https://api.anthropic.com/v1/messages', [
            'model'      => 'claude-haiku-4-5-20251001',  // Modelo ligero y rápido (barato)
            'max_tokens' => 1024,
            'messages'   => [
                [
                    'role' => 'user',
                    'content' => "Eres un asistente inteligente de la empresa PROYINSTAL que ayuda a consultar información sobre proyectos de delineación y topografía.

Tienes acceso a los siguientes datos de proyectos (formato JSON):

{$contexto}

El usuario ha preguntado lo siguiente:
\"{$mensaje}\"

Responde en español, de forma clara y concisa. Si el usuario pide proyectos filtrados por fecha, estado, cliente u otro criterio, filtra la lista correctamente y muéstrate los resultados de forma legible. Si no encuentras información relevante, dísele educadamente. No inventes datos que no estén en la lista proporcionada."
                ]
            ]
        ]);

        // ── Procesar respuesta ──
        if ($respuesta->successful()) {
            $body = $respuesta->json();
            $texto = $body['content'][0]['text'] ?? 'No se pudo obtener respuesta.';
            return response()->json(['respuesta' => nl2br(htmlspecialchars($texto))]);
        }

        // Error de la API
        return response()->json([
            'respuesta' => 'Ha ocurrido un error al conectar con el asistente IA. Por favor, inténtalo de nuevo más tarde.'
        ]);
    }
}