<x-app-layout>
<link rel="stylesheet" href="{{ asset('css/proyinstal-styles.css') }}">
<link rel="stylesheet" href="{{ asset('css/chatbot-styles.css') }}">

<!-- Navbar PROYINSTAL -->
<nav class="navbar">
    <div class="navbar-container">
        <div class="navbar-logo">
            <img src="{{ asset('images/proyinstal-logo.png') }}" alt="PROYINSTAL">
        </div>
        <ul class="navbar-menu">
            <li><a href="{{ route('dashboard') }}" class="navbar-link">Dashboard</a></li>
            <li><a href="{{ route('proyectos.index') }}" class="navbar-link active">Proyectos</a></li>
            @if(auth()->user()->rol === 'admin')
                <li><a href="#" class="navbar-link">Usuarios</a></li>
            @endif
            <li><a href="{{ route('profile.edit') }}" class="navbar-link">Mi Perfil</a></li>
            <li>
                <form method="POST" action="{{ route('logout') }}" style="display:inline;">
                    @csrf
                    <button type="submit" class="navbar-link" style="background:none;border:none;cursor:pointer;color:#fff;">
                        Cerrar Sesión
                    </button>
                </form>
            </li>
        </ul>
    </div>
</nav>

<!-- ============================================
     LAYOUT: Tabla izquierda + Chat derecha (solo admin)
     Si es cliente: solo tabla ancha
     ============================================ -->

@if(auth()->user()->rol === 'admin')
<!-- ADMIN: Layout dividido tabla + chatbot -->
<div class="proyectos-chat-layout">

    <!-- PANEL IZQUIERDO: Tabla de proyectos -->
    <div class="proyectos-panel">
        <div class="proyectos-panel-header">
            <h2>Todos los Proyectos</h2>
            <button class="btn-nuevo-proyecto">+ Nuevo Proyecto</button>
        </div>

        <div class="proyectos-tabla-wrap">
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Proyecto</th>
                        <th>Cliente</th>
                        <th>Estado</th>
                        <th>Tipo</th>
                        <th>Fecha Inicio</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Datos de ejemplo (se reemplazarán con datos reales de la BD) -->
                    <tr>
                        <td>1</td>
                        <td style="font-weight:600; color:#001F7A;">Vivienda Unifamiliar Pamplona</td>
                        <td>Juan García López</td>
                        <td><span class="badge badge-en-proceso">En Proceso</span></td>
                        <td>Vivienda</td>
                        <td>15/01/2025</td>
                        <td><a href="#" class="link" style="font-size:0.82rem;">Ver</a></td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td style="font-weight:600; color:#001F7A;">Reforma Local Comercial</td>
                        <td>María Sánchez</td>
                        <td><span class="badge badge-completado">Completado</span></td>
                        <td>Reforma</td>
                        <td>02/12/2024</td>
                        <td><a href="#" class="link" style="font-size:0.82rem;">Ver</a></td>
                    </tr>
                    <tr>
                        <td>3</td>
                        <td style="font-weight:600; color:#001F7A;">Edificio Residencial</td>
                        <td>Pedro Martínez</td>
                        <td><span class="badge badge-pendiente">Pendiente</span></td>
                        <td>Edificio</td>
                        <td>20/01/2025</td>
                        <td><a href="#" class="link" style="font-size:0.82rem;">Ver</a></td>
                    </tr>
                    <tr>
                        <td>4</td>
                        <td style="font-weight:600; color:#001F7A;">Topografía Terreno Industrial</td>
                        <td>Construcciones García S.L.</td>
                        <td><span class="badge badge-en-proceso">En Proceso</span></td>
                        <td>Topografía</td>
                        <td>10/01/2025</td>
                        <td><a href="#" class="link" style="font-size:0.82rem;">Ver</a></td>
                    </tr>
                    <tr>
                        <td>5</td>
                        <td style="font-weight:600; color:#001F7A;">Instalaciones Eléctricas</td>
                        <td>Ana López</td>
                        <td><span class="badge badge-pausado">Pausado</span></td>
                        <td>Instalaciones</td>
                        <td>05/11/2024</td>
                        <td><a href="#" class="link" style="font-size:0.82rem;">Ver</a></td>
                    </tr>
                    <tr>
                        <td>6</td>
                        <td style="font-weight:600; color:#001F7A;">Nave Industrial Zaragoza</td>
                        <td>Industrias del Norte</td>
                        <td><span class="badge badge-completado">Completado</span></td>
                        <td>Industrial</td>
                        <td>18/03/2024</td>
                        <td><a href="#" class="link" style="font-size:0.82rem;">Ver</a></td>
                    </tr>
                    <tr>
                        <td>7</td>
                        <td style="font-weight:600; color:#001F7A;">Garaje Subterráneo</td>
                        <td>Comunidad de Vecinos</td>
                        <td><span class="badge badge-cancelado">Cancelado</span></td>
                        <td>Obra Civil</td>
                        <td>01/06/2024</td>
                        <td><a href="#" class="link" style="font-size:0.82rem;">Ver</a></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <!-- PANEL DERECHO: Chatbot estilo Tuenti -->
    <div class="chat-panel">

        <!-- Header -->
        <div class="chat-panel-header">
            <div class="chat-avatar-header">IA</div>
            <div class="chat-header-info">
                <span class="nombre">Asistente PROYINSTAL</span>
                <span class="estado"><span class="punto-verde"></span> En línea</span>
            </div>
        </div>

        <!-- Mensajes -->
        <div class="chat-mensajes" id="chatMensajes">
            <!-- Mensaje inicial del bot -->
            <div class="mensaje mensaje-bot">
                <div class="mensaje-avatar">IA</div>
                <div>
                    <div class="mensaje-globo">
                        <p>¡Hola! Soy el Asistente IA de PROYINSTAL. Puedo consultarte información sobre los proyectos. Por ejemplo:</p>
                        <ul>
                            <li>📂 "Dame los proyectos completados"</li>
                            <li>📅 "Proyectos entre enero y marzo 2025"</li>
                            <li>👤 "Proyectos del cliente Juan"</li>
                            <li>📊 "¿Cuántos proyectos hay en proceso?"</li>
                        </ul>
                    </div>
                    <span class="mensaje-hora">{{ date('H:i') }}</span>
                </div>
            </div>
        </div>

        <!-- Input -->
        <div class="chat-input-area">
            <div class="chat-input-row">
                <input
                    type="text"
                    id="inputMensaje"
                    placeholder="Escribe un mensaje..."
                    autocomplete="off"
                    onkeypress="if(event.key==='Enter') enviarMensaje()"
                >
                <button class="btn-enviar" id="btnEnviar" onclick="enviarMensaje()">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                        <line x1="22" y1="2" x2="11" y2="13"></line>
                        <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
                    </svg>
                </button>
            </div>
        </div>
    </div>
</div>

@else
<!-- CLIENTE: Solo tabla, sin chatbot -->
<div style="padding: 1.5rem; max-width: 1200px; margin: 0 auto;">
    <div class="proyectos-panel-header">
        <h2 style="font-size:1.25rem; font-weight:700; color:#001F7A;">Mis Proyectos</h2>
    </div>

    <div class="proyectos-tabla-wrap">
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Proyecto</th>
                    <th>Estado</th>
                    <th>Tipo</th>
                    <th>Fecha Inicio</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>1</td>
                    <td style="font-weight:600; color:#001F7A;">Vivienda Unifamiliar Pamplona</td>
                    <td><span class="badge badge-en-proceso">En Proceso</span></td>
                    <td>Vivienda</td>
                    <td>15/01/2025</td>
                    <td><a href="#" class="link" style="font-size:0.82rem;">Ver detalles</a></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
@endif

<!-- ============================================
     JAVASCRIPT DEL CHATBOT
     ============================================ -->
@if(auth()->user()->rol === 'admin')
<script>
(function() {
    const input       = document.getElementById('inputMensaje');
    const btnEnviar   = document.getElementById('btnEnviar');
    const container   = document.getElementById('chatMensajes');
    const CSRF        = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

    // ── Utilidades ────────────────────────────
    function ahora() {
        return new Date().toLocaleTimeString('es-ES', { hour:'2-digit', minute:'2-digit' });
    }

    function scrollAbajo() {
        container.scrollTop = container.scrollHeight;
    }

    // ── Añadir mensaje al DOM ─────────────────
    function añadir(texto, tipo) {   // tipo: 'bot' | 'usuario'
        const div = document.createElement('div');
        div.className = 'mensaje mensaje-' + tipo;

        const avatarDiv = document.createElement('div');
        avatarDiv.className = 'mensaje-avatar';
        avatarDiv.textContent = tipo === 'bot' ? 'IA' : auth()->user()->nombre[0] ?? 'U';

        const wrapDiv = document.createElement('div');

        const globoDiv = document.createElement('div');
        globoDiv.className = 'mensaje-globo';
        globoDiv.innerHTML = texto;

        const horaSpan = document.createElement('span');
        horaSpan.className = 'mensaje-hora';
        horaSpan.textContent = ahora();

        wrapDiv.appendChild(globoDiv);
        wrapDiv.appendChild(horaSpan);

        if (tipo === 'bot') {
            div.appendChild(avatarDiv);
            div.appendChild(wrapDiv);
        } else {
            div.appendChild(wrapDiv);
            div.appendChild(avatarDiv);
        }

        container.appendChild(div);
        scrollAbajo();
    }

    // ── Mostrar/ocultar indicador "escribiendo" ──
    function mostrarTyping() {
        const div = document.createElement('div');
        div.className = 'mensaje mensaje-bot';
        div.id = 'typingMsg';

        const avatarDiv = document.createElement('div');
        avatarDiv.className = 'mensaje-avatar';
        avatarDiv.textContent = 'IA';

        const globoDiv = document.createElement('div');
        globoDiv.className = 'typing-globo';
        globoDiv.innerHTML = '<span class="dot"></span><span class="dot"></span><span class="dot"></span>';

        div.appendChild(avatarDiv);
        div.appendChild(globoDiv);
        container.appendChild(div);
        scrollAbajo();
    }

    function borrarTyping() {
        const el = document.getElementById('typingMsg');
        if (el) el.remove();
    }

    // ── Enviar mensaje a la API del backend ──
    async function enviarMensaje() {
        const texto = input.value.trim();
        if (!texto) return;

        // Mostrar mensaje del usuario
        añadir('<p>' + texto + '</p>', 'usuario');
        input.value = '';
        btnEnviar.disabled = true;

        // Mostrar typing
        mostrarTyping();

        try {
            const res = await fetch('/chatbot/consulta', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': CSRF
                },
                body: JSON.stringify({ mensaje: texto })
            });

            const data = await res.json();
            borrarTyping();
            añadir('<p>' + data.respuesta + '</p>', 'bot');

        } catch (err) {
            borrarTyping();
            añadir('<p style="color:#dc2626;">Error de conexión. Por favor, inténtalo de nuevo.</p>', 'bot');
        }

        btnEnviar.disabled = false;
        input.focus();
    }

    // Scroll al final al cargar
    scrollAbajo();
})();
</script>
@endif

</x-app-layout>